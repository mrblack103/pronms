<?php
 
define('DB_USER', "root"); // db user
define('DB_PASSWORD', ""); // db password 
define('DB_DATABASE', "MosSecrets"); // database name
define('DB_SERVER', "localhost"); // db server
?>